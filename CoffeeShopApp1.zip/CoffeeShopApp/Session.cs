﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShopApp
{
    internal class Session
    {
        public static int UserId { get; set; }
        public static string FullName { get; set; }
        public static bool IsAdmin { get; set; }
    }
}
